#!/usr/bin/env python3
"""Entry point ShopDesk — chạy: python app.py (port 8000)."""
from app import create_app

app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
